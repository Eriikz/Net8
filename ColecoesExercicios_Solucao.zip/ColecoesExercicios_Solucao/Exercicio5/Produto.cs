﻿namespace Exercicio5;

public class Produto
{
    public string? Nome { get; set; }
    public decimal Preco { get; set; }
}
    