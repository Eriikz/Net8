﻿namespace _8Heranca_Tipos;

internal class E : D
{
    public void Mostrar()
    {
        Console.WriteLine("Método da classe B");
    }
}
