﻿namespace _8Heranca_Tipos;

internal class B : A
{
    public void Mostrar()
    {
        Console.WriteLine("Método da classe B");
    }
}
