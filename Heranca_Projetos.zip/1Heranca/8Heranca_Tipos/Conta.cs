﻿namespace _8Heranca_Tipos;

public class Conta
{
    public int Numero { get; set; }
    public double Saldo { get; private set; }
}
