﻿namespace _8Heranca_Tipos;

internal class A
{
    public void Exibir()
    {
        Console.WriteLine("Método da classe A");
    }
}
