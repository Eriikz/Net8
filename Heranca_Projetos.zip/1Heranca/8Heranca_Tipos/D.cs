﻿namespace _8Heranca_Tipos;

internal class D
{
    public void Exibir()
    {
        Console.WriteLine("Método da classe A");
    }
}
