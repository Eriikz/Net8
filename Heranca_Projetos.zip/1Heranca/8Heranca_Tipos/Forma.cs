﻿namespace _8Heranca_Tipos;

internal class Forma
{
    public void SetLado(int s)
    {
        lado = s;
    }
    protected int lado;
}
