﻿namespace _8Heranca_Tipos;

internal interface ICusto
{
    int GetCusto(int area);
}
