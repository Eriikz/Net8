﻿namespace _8Heranca_Tipos;

public class ContaPoupanca : Conta
{
    public int JurosMensais { get; set; }
}
