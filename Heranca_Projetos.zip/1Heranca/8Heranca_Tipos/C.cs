﻿namespace _8Heranca_Tipos;

internal class C : A
{
    public void Apresentar()
    {
        Console.WriteLine("Método da Classe C");
    }
}
