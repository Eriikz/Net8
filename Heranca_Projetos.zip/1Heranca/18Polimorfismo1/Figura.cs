﻿namespace _18Polimorfismo1;

public class Figura
{
    public virtual void Desenhar()
    {
        Console.WriteLine("Executando Desenhar na classe base");
    }
}
