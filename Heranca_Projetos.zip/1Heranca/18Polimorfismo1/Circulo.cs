﻿namespace _18Polimorfismo1;

public class Circulo : Figura
{
    public override void Desenhar()
    {
        Console.WriteLine("Desenhando um circulo...");
    }
}
