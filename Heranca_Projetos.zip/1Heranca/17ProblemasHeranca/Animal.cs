﻿namespace _17ProblemasHeranca;

public class Animal
{
    public int Idade { get; set; }
    public void Comer() { }
    public void Dormir() { }
}
