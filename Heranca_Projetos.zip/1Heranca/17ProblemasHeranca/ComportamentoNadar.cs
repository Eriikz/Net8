﻿namespace _17ProblemasHeranca;

public class ComportamentoNadar
{
    public void Nadar()
    {
        Console.WriteLine(" Nadando...");
    }
}
