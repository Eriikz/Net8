﻿namespace _17ProblemasHeranca;

public class ComportamentoAndar
{
    public void Andar()
    {
        Console.WriteLine(" Andando...");
    }
}
