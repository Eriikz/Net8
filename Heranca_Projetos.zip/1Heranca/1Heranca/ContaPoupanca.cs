﻿namespace _1Heranca;

public class ContaPoupanca : Conta
{
    public int JurosMensais { get; set; }
}
