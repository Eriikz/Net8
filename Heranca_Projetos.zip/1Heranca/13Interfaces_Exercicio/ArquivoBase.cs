﻿namespace _13Interfaces_Exercicio;

public abstract class ArquivoBase
{
    public virtual void Nome()
    {
        Console.WriteLine("Definir o nome do arquivo");
    }
}
