﻿namespace _15Composicao;

internal class Logger
{
    public void Log(string mensagem)
    {
        Console.WriteLine("Logando : " + mensagem);
    }
}
