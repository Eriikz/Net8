﻿
var gato = new Gato() { Nome = "bichano" };
gato.ExibeNome();

var cao = new Cachorro() { Nome = "pipoca" };
cao.ExibeNome();

Console.ReadKey();
