﻿


class Cachorro : Animal
{

}