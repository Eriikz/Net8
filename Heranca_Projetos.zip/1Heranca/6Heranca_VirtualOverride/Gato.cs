﻿


//classe derivada
class Gato : Animal
{
    public override void ExibeNome()
    {
        Console.WriteLine($"\nEu sou um gato. Meu nome é  : {Nome}");
    }
}
