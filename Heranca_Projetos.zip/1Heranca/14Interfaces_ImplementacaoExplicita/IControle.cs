﻿namespace _14Interfaces_ImplementacaoExplicita;

public interface IControle
{
    void Desenhar();
}
