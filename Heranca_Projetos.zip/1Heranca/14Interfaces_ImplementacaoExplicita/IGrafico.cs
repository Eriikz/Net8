﻿namespace _14Interfaces_ImplementacaoExplicita;

public interface IGrafico
{
    void Desenhar();
}
