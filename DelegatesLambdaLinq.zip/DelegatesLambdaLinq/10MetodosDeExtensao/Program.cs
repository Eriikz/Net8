﻿
using _10MetodosDeExtensao;

string texto = "Usando métodos de extensão";

string textoInvertido = texto.InverteString();

Console.WriteLine(textoInvertido);

Console.ReadKey();