﻿namespace _02TaskProgAssincrona;

public class Cafe
{}
