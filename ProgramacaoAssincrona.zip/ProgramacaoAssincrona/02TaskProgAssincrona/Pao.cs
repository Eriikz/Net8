﻿namespace _02TaskProgAssincrona;

public class Pao
{}
